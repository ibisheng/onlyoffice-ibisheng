window.onload = function()
{
	var elem = document.getElementById("test");
	elem.contentEditable = "true";

	elem.focus();

	elem.oncopy = function(e)
	{
		var _clipboard = (e === undefined || e.clipboardData === undefined) ? window.clipboardData : e.clipboardData;
		if (e && e.preventDefault)
			e.preventDefault();
				
		_clipboard.setData("text/plain", "oleg");
		_clipboard.setData("application/octet-stream", "docdata");
		
		// IE: (Text only!!!) 
		//_clipboard.setData("Text", "oleg");
		
		return false;
	};
	elem.onpaste = function(e)
	{
		if (e && e.preventDefault)
			e.preventDefault();
		
		var _clipboard = (e === undefined || e.clipboardData === undefined) ? window.clipboardData : e.clipboardData;
		
		var _text = _clipboard.getData("text/plain");
		var _bin = _clipboard.getData("application/octet-stream");
		
		// IE: (Text only!!!) 
		//_clipboard.getData("Text");

		console.log(_text);
		return false;
	};
	elem.onbeforecopy = function(e)
	{
		elem.focus();
		if (document.selection) 
		{
            var range = document.body.createTextRange();
            range.moveToElementText(elem);
            range.select();
        } 
        else if (window.getSelection) 
        {
            var range = document.createRange();
            range.selectNode(elem.firstChild);
            window.getSelection().addRange(range);
        }
	};
	elem.onbeforepaste = function(e)
	{
		elem.focus();
	};
}